package com.Billingoptions;
abstract class Billingwithoffer extends baseBilling {

	static double discount = 0.1;
	public static void applydiscount(double discountpercentage)
	{
		discount = discountpercentage;
	}
	
}