package com.Billingoptions;

abstract class baseBilling implements IBilling {

	public double calculateCost(double quantity, double rate)
	{
		return quantity*rate;
	}
	public double calculatebill(double cost, double tax)
	{
		return cost + cost*tax;
	}
}
