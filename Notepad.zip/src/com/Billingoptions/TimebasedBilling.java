package com.Billingoptions;

public class TimebasedBilling extends basebillingwithoffer{


	boolean canapplydiscount = false;
	@Override
	public void applydiscount(double discountpercent) {
		// TODO Auto-generated method stub
 
			this.discoutpercentage = discountpercent;
	
		
	}

}