package com.Billingoptions;

public interface IBilling {

	double calculatebill(double cost, double tax);
	
	double calculateCost(double quantity, double rate);
}