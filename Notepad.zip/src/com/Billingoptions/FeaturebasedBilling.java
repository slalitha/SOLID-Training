package com.Billingoptions;

public class FeaturebasedBilling extends basebillingwithoffer{

	@Override
	public void applydiscount(double discountpercent) {
		// TODO Auto-generated method stub

			discoutpercentage = discountpercent;
		
	}

	

	
	
}