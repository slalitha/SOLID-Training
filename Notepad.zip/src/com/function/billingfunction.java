package com.function;
import java.text.DecimalFormat;

public class billingfunction {

	Notepad notepad = Notepad.getInstance();
	
	private double timebasedcost;
	private double GST = 0.1;
	private double totalCost; // totalcost = timebasedcost + uploadcost + subscription
	//private double discount = 0.10;
	//private double donation = 100;
	
	private long totalTime;
	
	 
	public double applyGST(double cost)
	{
		return cost*GST;
	}
	public double calcTimebasedcost()
	{
		long endTime   = System.nanoTime();
		totalTime = (endTime - notepad.startTime)/1000000000;
		double timebasedcost = (totalTime/60.0)*(1/60.0);
		return timebasedcost;
	}
	public void generatebill() {
		calcTimebasedcost();
		GST = applyGST(totalCost);
		
		
		notepad.TotatCost = timebasedcost + GST;
		displaybill();
	}
	public void displaybill()
	{
		notepad.bill.label.setText(notepad.bill.label.getText() + " " + totalTime + " sec.");	
		notepad.bill.textPane.setText(new DecimalFormat("##.####").format(timebasedcost) + "$");
		notepad.bill.textPane_2.setText(new DecimalFormat("##.####").format(notepad.TotatCost) + "$");
		notepad.bill.frame.setVisible(true);
	}
}
