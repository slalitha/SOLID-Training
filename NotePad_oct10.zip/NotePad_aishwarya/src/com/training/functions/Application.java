package com.training.functions;

public class Application {
	public static void main(String[] args) {
		NotePad notePad = new NotePad();
		notePad.setVisible(true);
	}
}